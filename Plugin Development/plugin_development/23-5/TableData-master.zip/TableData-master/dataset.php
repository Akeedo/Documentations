<?php
$data = [
	[
		'id'=>1,
		'name'=>'John Doe',
		'email'=>'john@doe.com',
		'age'=>23,
		'sex'=>'M'
	],[
		'id'=>2,
		'name'=>'Jane Doe',
		'email'=>'jane@doe.com',
		'age'=>24,
		'sex'=>'F'
	],[
		'id'=>3,
		'name'=>'Jimmy Doe',
		'email'=>'jimmy@doe.com',
		'age'=>21,
		'sex'=>'M'
	],[
		'id'=>4,
		'name'=>'Jessy Doe',
		'email'=>'jessy@doe.com',
		'age'=>26,
		'sex'=>'F'
	],[
		'id'=>5,
		'name'=>'Jack Doe',
		'email'=>'jack@doe.com',
		'age'=>27,
		'sex'=>'M'
	],[
		'id'=>6,
		'name'=>'Jason Doe',
		'email'=>'jason@doe.com',
		'age'=>28,
		'sex'=>'M'
	],[
        'id'=>7,
        'name'=>'John Wick',
        'email'=>'john@wick.com',
        'age'=>26,
        'sex'=>'M'
    ]
];